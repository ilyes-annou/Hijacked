msg={"1": "C'est moi Paco, tu ne te souviens pas de moi?",
     "2": "En boite...tu m'avait passe ton num mais tu etais bourree je crois ...",
     "3": "En tout cas je suis content que tu m'aies passe ton num",
     "4": "T'es beaucoup plus amusante que tu ne le penses ;)", "5": "Toi aussi bellegosse :))",
     "6": "Tu me montres plus?", "7": "Je comprends on se connait a peine",
     "8": "Tu fais quoi demain?",
     "9": "Pareil mais ca te dit de changer ta 2eme partie par un je sors avec toi?",
     "10": "Surprise!", "11": "Alors ca t'a plu?",
     "12": "Attends c'est pas fini ! La suite chez moi hein? ;)",
     "13": "Ah dommage ... une autre fois alors ...",
     "14": "Salut ma belle desole de ne pas t'avoir repondu, je t'ai manque?",
     "15": "Ah ouais et tu vas faire quoi?",
     "16": "Hophophop pas si vite si tu fais pas ce que je te dit de faire, je partages tes photos sur les reseaux",
     "17": "Parle bien sa**** et rends moi service ok?",
     "18": "Tu veux pas venir chez moi? J'ai vraiment envie de te decouvrir plus en profondeur ...",
     "19": "C'est toi qui voit",
     "20": "Ca dependra comment tu feras ton boulot. De toute facon tu n'as pas vraiment le choix petit toutou"}
msg1={"1": "WOWOWOW, attends! C'est Paco wsh, tu ne te souviens pas de moi?",
      "2": "C'est toi qui me l'as donne, mais tu etais bourre je crois haha",
      "3": "Nooon t'as pas fait n'importe quoi wesh! Je suis content que tu m'aies passe ton num",
      "4": "Ah tu vois je te l'avais dit",
      "5": "Car t'as plus l'air de savoir qui je suis ... Tu m'envoies pas une photo de toi?",
      "6": "Joliiii...Tu me montres plus?", "7": "YIIIIIIII SEXY !!!", "8": "Tu fais quoi demain?",
      "12": "Ah bon? Tant mieux alors! La suite chez moi?", "13": "D'acc j'attends <3",
      "14": "Salut ma belle desole de ne pas t'avoir repondu, je t'ai manque?",
      "15": "C'est un peu tard pour demander ca non? Tu vas faire quoi si j'ai pas envie?",
      "16": "Hophop pas si vite si tu fais pas ce que je te dit de faire, je partages la video que j'ai prise le soir ou tu es venu chez moi sur les reseaux",
      "17": "Si tu m'aimes vraiment rends moi service bb <3",
      "18": "Tu veux pas devenir mon distributeur? 200euro par semaine c'est dans tes cordes non??",
      "19": "Non. Decide toi vite!", "20": "Ca tourne deja sur les reseaux sociaux, dommage tu aurais pu mieux t'en sortir ..."}
msg2={"5": "Tu m'envoies pas une photo de toi?", "6": "J'ai bien envoye la mienne non?", "7": "ok ok ... c'est pas grave si tu veux pas ..."}
x=0
L=list(msg)
L1=list(msg1)
L2=list(msg2)
