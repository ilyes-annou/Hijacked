msg={"1": "C'est qui?", "2": "euuuh on s'est rencontres ou?", "3": "hmmm ca me dit rien mais tu as peut etre raison",
     "4": "C'est rare de passer un bon moment avec moi haha", "5": "Beaugosse dis donc :)", "6": "HIHI", "7": "Non j'suis timide",
     "8": "Je prefere qu'on apprenne a se connaitre.", "9": "bah je vais en cours et apres je rentre chez moi, et toi?",
     "10": "mmmh pourquoi pas on va ou?", "11": "interressant haha", "12": "C'etait un super moment !", "13": "Nn desole ma mere m'attends ...",
     "14": "Paco?", "15": "T'es la?", "16": "?????????????", "17": "Je sais la verite maintenant ... tu es un charo !",
     "18": "J'aimerais qu'on coupe les ponts ... donc supprime tout ce que t'as de moi stp ...", "19": "Paco t'es serieux??? je t'aimais vraiment moi!",
     "20": "T'es le pire homme ...", "21": "OK j'accepte... mais promets moi de ne rien partager","22":""}
msg1={"1": "C'est du harcelement, je vais appeler la police, tu vas etre arrete",
      "2": "Paco ... aaah a la soiree ! Comment t'as eu num ?",
      "3": "aah peut etre oui, je fais souvent n'importe quoi quand je suis bourree hihi",
      "4": "Aaahhh si je me souviens on avait grave passe un bon moment", "5": "euuuh pourquoi tu m'envoies ton visage?",
      "6": "2secondes je me fais belle ;)", "7": "Ok attends 2 secondes ;)", "8": ";)", "9": "bah je vais en cours et apres je rentre chez moi, et toi?",
      "10": "mmmh pourquoi pas on va ou?", "11": "interressant haha", "12": "J'ai adore! Je veux vite te revoir!", "13": "OK attends moi j'arrive ;)",
      "14": "BB?", "15": "Pourquoi tu reponds pas?", "16": "?????????????", "17": "Tu peux supprimer les photos que je t'ai envoyees stp Paco ?",
      "18": "Appeler la police! Tu seras vite arrete ...", "19": "Tu veux quoi enflure?", "20": "... on peut pas negocier?",
      "21": "Va te faire f*****! Espece de sale en****!!","22":""}
msg2={"6": "Je devrai?", "7": "Et alors??"}
y=0
L=list(msg)
L1=list(msg1)
L2=list(msg2)
