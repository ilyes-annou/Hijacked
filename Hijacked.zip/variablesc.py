c=0
CHECKPOINT=0
dejafait=0
passe=1
askyn=0
