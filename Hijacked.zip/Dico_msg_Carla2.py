msg={"1":"Un probleme peut etre ??"}

msg1={"1":"Je ne sors pas encore vraiment avec lui … "}
   
msgrien2={"1":"Je ne sors pas encore vraiment avec lui … ",
          "2":"Jure !!!! ",
          "3":"on est parti en date après il m’a demandé de venir chez lui j'ai dit non",
          "4":"Je ne pense pas qu’il soit si mechant que ca, t’abuserais pas un peu?",
          "5":"je ne lui ai rien envoye de toute facon …",
          "6":"D’accord je le bloque… je veux pas que ca arrive",}

msgphoto1={"1":"Un probleme peut etre ??",
           "2":"Jure !!!! ",
           "3":"on est parti en date après il m’a demandé de venir chez lui j'ai dit non",
           "4":"Je ne pense pas qu’il soit si mechant que ca, t’abuserais pas un peu?",
           "5":"Oh nan jlui est envoye des photos de moi",
           "6":"nan c’est la honte et il me renieront",
           "7":" non, j’ai trop peur finalement",
           "8":"",
           "9":""}

msgphoto2={"1":"Je ne sors pas encore vraiment avec lui … ",
           "2":"Jure !!!! ",
           "3":"on est parti en date après il m’a demandé de venir chez lui j'ai dit non",
           "4":"Je ne pense pas qu’il soit si mechant que ca, t’abuserais pas un peu?",
           "5":"Oh nan jlui est envoye des photos de moi",
           "6":"Je devrai tu penses ?",
           "7":"Ok je vais le faire … ",
           "8":"",
           "9":""}

msgvideo1={"1":"Un probleme peut etre ??",
           "2":"Jure !!!! ",
           "3":"on est parti en date après il m’a demandé de venir chez j'y suis allée",
           "4":"Je ne pense pas qu’il soit si mechant que ca, t’abuserais pas un peu?",
           "5":"Oh nan on l’a fait chez lui ... ",
           "6":"Je devrai tu penses ?",
           "7":" non, j’ai trop peur finalement",}

msgvideo2={"1":"Je ne sors pas encore vraiment avec lui … ",
           "2":"Jure !!!! ",
           "3":"on est parti en date après il m’a demandé de venir chez j'y suis allée",
           "4":"Je ne pense pas qu’il soit si mechant que ca, t’abuserais pas un peu?",
           "5":"Oh nan on l’a fait chez lui ... ",
           "6":"nan c'est la honte et ils me renieront",
           "7":"Ok je vais le faire … "}

x=0
L=list(msgphoto1)
