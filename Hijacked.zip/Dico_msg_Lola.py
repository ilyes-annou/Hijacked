msgrien2={"1":"C'est un charo il est connu pour sa ",
     "2":"Vous avez fait quoi ?",
     "3":"t'as bien fait, je te conseille de le bloquer de partout",
     "4":"C'est grave de ouf il est tres malintentionne",
     "5":"Bloque le alors et oublie cette histoire !",}

msgphoto={"1":"C'est un charo il est connu pour sa ",
      "2":"Vous avez fait quoi ?",
      "3":"t'as bien fait, je te conseille de le bloquer de partout",
      "4":"C'est grave de ouf il est tres malintentionne", 
      "5":"Parles en a tes parents ca peut devenir un serieux pb",
      "6":"Viens pas te plaindre si il t'arrive qqchose",
      "7":"Viens pas te plaindre si il t'arrive qqchose"}

msgphoto2={"1":"C'est un charo il est connu pour sa ",
      "2":"Vous avez fait quoi ?",
      "3":"t'as bien fait, je te conseille de le bloquer de partout",
      "4":"C'est grave de ouf il est tres malintentionne", 
      "5":"Parles en a tes parents ca peut devenir un serieux pb",
      "6":"OUI",
      "7":"OUI",
      "8":"     ",
      "9":"     "}

msgreste={"1":"C'est un charo il est connu pour sa ",
      "2":"Vous avez fait quoi ?",
      "3":"Maiiss t'es folle",
      "4":"C'est grave de ouf il est tres malintentionne", 
      "5":"Parles en a tes parents ca peut devenir un serieux pb",
      "6":"Viens pas te plaindre si il t'arrive qqchose"}

msgreste2={"1":"C'est un charo il est connu pour sa ",
      "2":"Vous avez fait quoi ?",
      "3":"Maiiss t'es folle",
      "4":"C'est grave de ouf il est tres malintentionne", 
      "5":"Parles en a tes parents ca peut devenir un serieux pb",
      "6":"OUI",
      "7":"OUI",
      "8":"     ",
      "9":"     "}


x=0
L=list(msgphoto2)
